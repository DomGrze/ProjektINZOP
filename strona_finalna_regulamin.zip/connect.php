<?php

$host = "mkwk107.cba.pl";
$db_user = "domabaSQL";
$db_password = "BialasSQL2115";
$db_name = "domaba69";
    
?>
